#include <iostream>

int main() {
    std::cout << "PIFRENUC C++ ENGINE: Running at Maximum Efficiency!" << std::endl;
    return 0;
}